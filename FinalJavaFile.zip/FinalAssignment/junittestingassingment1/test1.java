package junittestingassingment1;

import java.io.FileReader;
import java.io.IOException;

import org.junit.jupiter.api.Test;

class test1 {

	@Test
		public void testReadFile() throws IOException { 
		
		FileReader reader = new FileReader("C:\\Users\\MALew\\Desktop\\Module2\\assignmentmodule2\\The Project Gutenberg eBook of The Raven, by Edgar Allan Poe.txt");
		reader.read();
        reader.close();

	}

}
