module FinalAssignment {
	requires java.desktop;
}