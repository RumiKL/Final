package FinalAssignement;

public class fabonacciAssignment {
	public static void main(String[] args) {
		int numbers = 10;
		
		
		System.out.println("Fibonacci Sequence - Iterative");
		
		for (int i = 1; i <= numbers; i++)
		{
				int fibonacci = Fibonacci_Iterative(i);
				String text = String.format("Fibonacci of %s is %s", i, fibonacci);
				System.out.println(text);
		}
		
		
		System.out.println("Fibonacci Sequence - Recursive");
		for (int i = 1; i <= numbers; i++)
		{
				int fibonacci = Fibonnacci_Recursive(i);
				String text = String.format("Fibonacci of %s is %s", i, fibonacci);
				System.out.println(text);
	}
}
	
	static int Fibonacci_Iterative(int n) {
		int fn_1 = 1;
		int fn_2 = 1;
		
		for (int i = 3; i <= n; i++) {
			int fn_2Aux = fn_1;
			fn_1 = fn_2 + fn_1;
			fn_2 = fn_2Aux;
		}
		
		return fn_1;
		
		
	}
	
	static int Fibonnacci_Recursive(int n) {
		if (n == 1 || n == 2)
			return 1;
		else
			return Fibonnacci_Recursive(n - 2) + Fibonnacci_Recursive(n - 1);
	}
}


