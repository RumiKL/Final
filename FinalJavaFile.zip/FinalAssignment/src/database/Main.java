package database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class Main {
	
	public static Connection getConnection() throws Exception{
		try {
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/word occurences";
			String username = "root";
			String password = "ILoveMyChildren1!";
			Class.forName(driver);
			
			Connection conn = DriverManager.getConnection(url,username,password);
			System.out.println("Connected");
			return conn;
		}catch(Exception e) {System.out.println(e);}
				return null;
		}
	


	public static void main(String[] args) throws Exception{
		createTable();
		post();
		get();
	}
	
	public static ArrayList<String> get() throws Exception{
		try {
			Connection con = getConnection();
			PreparedStatement statement = con.prepareStatement("SELECT id, wordcol, FROM word");
			
			ResultSet result = statement.executeQuery();
			
			ArrayList<String> array = new ArrayList<String>();
			while(result.next()) {
				System.out.println(result.getString("id"));
				System.out.print(" ");
				System.out.println(result.getString("wordcol"));
				System.out.print(" ");
				array.add(result.getString("wordcol"));
			}
			System.out.println("All records have been selected!");
			return array;
		
		}catch(Exception e) {System.out.println(e);}
			return null;
			
		}
		@SuppressWarnings("unused")
		public static void post() throws Exception{
			final String wordcol = "John";
			try {
				Connection con = getConnection();
				PreparedStatement posted = con.prepareStatement("INSERT INTO word (id, wordcol) VALUES (5, wordcol)");
				
				posted.executeUpdate();
			}catch(Exception e) {System.out.println(e);}
		finally{
			System.out.println("Insert Completed.");			
		}
			}
		public static void createTable() throws Exception{
	
			}
		}